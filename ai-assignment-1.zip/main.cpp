documentclass[a4paper,10pt]{article} 
\usepackage[utf8]{inputenc}
 \begin{center}
    \large{NATIONAL INSTITUTE OF TECHNOLOGY RAIPUR}
\end{center}

\title{AI_PHILOSOPHY}
\date{July 2021}

\begin{document}

%-------------------------------
    %	TITLE SECTION
    %-------------------------------
    \fancyhead{}
    \hrule \medskip % Upper rule
    \begin{minipage}{0.295\textwidth} 
    \raggedright
    \footnotesize
 Raj kumar\hfill\\
   19111044\hfill\\
   BIOMED 5th SEM
    \end{minipage}
    \begin{minipage}{0.4\textwidth} 
    \centering 
    \large 
    ASSIGNMENT 1\\
    \normalsize 
    Philosophy of Artificial Intelligence\\ 
    \end{minipage}
    \begin{minipage}{0.295\textwidth} 
    \raggedleft
    \today\hfill\\
    \end{minipage}
    \medskip\hrule 
    \bigskip
    
\section{Introduction}

The philosophy of artificial intelligence is a branch of the philosophy of technology that explores artificial intelligence and its implications for knowledge and understanding of intelligence, ethics, consciousness, epistemology, and free will.These factors contributed to the emergence of the philosophy of artificial intelligence. Some scholars argue that the AI community's dismissal of philosophy is detrimental.
The philosophy of artificial intelligence attempts to answer such questions as follows:\\
1]. Can a machine act intelligently? Can it solve any problem that a person would solve by thinking?\\
2]. Are human intelligence and machine intelligence the same? Is the human brain essentially a computer?\\
3]. Can a machine have a mind, mental states, and consciousness in the same sense that a human being can? Can it feel how things are?\\
Questions like these reflect the divergent interests of AI researchers, cognitive scientists and philosophers respectively. The scientific answers to these questions depend on the definition of "intelligence" and "consciousness" and exactly which "machines" are under discussion.
\section{ Can a Machine display general intelligence?}
This statement, which appeared in the proposal for the Dartmouth workshop in1956, sums up the basic position of most AI researchers:”Every aspect of learning or any other feature of intelligence can be so precisely described that a machine can be made to simulate it.” To answer the question, the first step is to define ”intelligence.” According to Alan Turing,if a machine can answer any question put to it, using the same words that an ordinary person would, then we may call that machine intelligent. According to Intelligent agent definition,if an agent acts so as to maximize the expected value of a performance measure based 
\section{Is symbol processing human think?}
Both human and machine intelligence, according to A, is based on "symbol
manipulation." They expressed themselves as follows:
●"A physical symbol system possesses the necessary and sufficient means of general intelligent action," which suggests both that human thinking is a form of symbol
manipulation (because a symbol system is required for intelligence) and that machines can be intelligent
● "The mind can be understood as a device that operates on pieces of data according to formal rule

\section {Is it possible for a computer to have awareness, mind, or mental states?}
John Searle argued that even if we had a computer program that acted exactly like a human mind, there would still be a difficult philosophical question that needed to be answered. John Searle’s two positions do not directly an-swer the question “can a machine display general intelligence?” Science fiction writers use it to describe some essential property that makes us human: intelligence, desires, will, insight, pride and so on. John Searle asks us to consider a
thought experiment: suppose we have written a computer program that passes the Turing test and demonstrates general intelligent action. He concludes that the Chinese room, or any other physical symbol system, cannot have a mind.Searle’s argument is just a version of the problem of other minds, applied
tomachines. The question is whether “consciousness” exist.
\section{Is  thinking  a kind of computation ?}
According to computationalism, the link between the mind and the brain is comparable (if not identical) to that between a running programme and a computer. This question relates to the previous ones: if the human brain is a type of computer, then computers can be intelligent and conscious, answering both the practical and philosophical questions of the previous questions.. In terms of the practical question of AI,Can a machine display general intelligence?
I) To put it another way, intelligence is derived from a type of computation comparable to arithmetic. It also suggests that artificial intelligence is conceivable. Most variants of computationalism assert that a machine can have a mind, mental states, and consciousness in terms of the philosophical question of AI, Can a machine have a mind, mental states, and consciousness?
Il) Mental states are merely (the correct) computer programmes in action.
Can a machine have emotions? and other related questions Is it possible for a machine to have its own consciousness? Is it possible for a machine to be inventive or original? Is it possible for a machine to be good or bad? , Is it possible for a machine to mimic every aspect of human behaviour? Is there such a thing as a soul for a machine?
\section {View on the role of Philosophy}
Some philosophers argue that the role of philosophy in AI is underappreciated.
Physicist David Deutsch argues that without an understanding of philosophy
or its concepts, AI development would suffer from a lack of progress. The
Sandford Encyclopaedia of Philosophy argues that the AI community’s dismissal
of philosophy is determined\\


\textbf{Important keywords :- Knowledge,Intelligence,Epistemology,Ethics,Consciousness,Computation,
Freewill,Symbol processing,Robotics,Intelligence Agent }

\end{document}

